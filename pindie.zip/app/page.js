
export default function Home() {
  return (
  <main>
        <html lang="ru">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>PINDIE — Портал инди-игр от студентов Яндекс Практикума</title>
        <link rel="stylesheet" href="./public/fonts/fonts.css" />
        <link rel="stylesheet" href="./styles/style.css" />
      </head>
      <body>
        <header className="header">
          <a href="./index.html" className="logo">
            <img className="logo__image" src="./images/logo.svg" alt="Логотип Pindie" />
          </a>
          <nav className="menu">
            <ul className="menu__list">
              <li className="menu__item">
                <a href="./news.html" className="menu__link">Новинки</a>
              </li>
              <li className="menu__item">
                <a href="./popular.html" className="menu__link">Популярные</a>
              </li>
              <li className="menu__item">
                <a href="./shooters.html" className="menu__link">Шутеры</a>
              </li>
              <li className="menu__item">
                <a href="./slashers.html" className="menu__link">Ранеры</a>
              </li>
            </ul>
          </nav>
        </header>
        <main className="main">
          <section className="banner">
            <div className="banner__description">
              <h1 className="banner__title">
                Портал инди-игр от&nbsp;студентов Яндекс Практикума
              </h1>
              <div className="banner__text-block">
                <p className="banner__text">
                  Студенты курсов разрабатывают свои игры на Unity, здесь мы их
                  публикуем. Вы можете играть прямо на сайте. А если у вас есть
                  аккаунт пользователя — получаете возможность голосовать за игры.
                </p>
              </div>
              <a href="#popular" className="button banner__link">Смотреть игры</a>
            </div>
            <img
              src="./images/banner-illustration.jpg"
              alt="Рука, утопленная в желтом фоне"
              className="banner__image"
            />
          </section>
          <section className="list-section">
            <h2 className="list-section__title" id="popular">
              Популярное
            </h2>
            <ul className="cards-list">
              <li className="cards-list__item">
                <a href="/game-id.html" className="card-list__link">
                  <article className="card">
                    <img
                      src="https://code.s3.yandex.net/teens/pindie-games/cristal-keeper/cover.png"
                      alt=""
                      className="card__image"
                    />
                    <div className="card__content-block">
                      <h3 className="card__title">Crystal Kepper</h3>
                      <p className="card__description">
                        Управляй боевым дроном, чтобы любой ценой защитить кристалл от враждебных космо-слизней.
                      </p>
                      <div className="card__info-container">
                        <p className="card__author">
                          Автор: <span className="card__accent">Lonely Baobab</span>
                        </p>
                        <p className="card__votes">
                          Голосов на сайте: <span className="card__accent">20</span>
                        </p>
                      </div>
                    </div>
                  </article>
                </a>
              </li>
              <li className="cards-list__item">
                <a href="/game-id.html" className="card-list__link">
                  <article className="card">
                    <img
                      src="https://code.s3.yandex.net/teens/pindie-games/dangeons-n-caves-prologue/cover.png"
                      alt=""
                      className="card__image"
                    />
                    <div className="card__content-block">
                      <h3 className="card__title">Dangeons'n'Caves. Prologue</h3>
                      <p className="card__description">
                        Безымянный герой исследует пещеры и подземелья, чтобы найти больше информации о себе.
                      </p>
                      <div className="card__info-container">
                        <p className="card__author">
                          Автор: <span className="card__accent">F-Style</span>
                        </p>
                        <p className="card__votes">
                          Голосов на сайте: <span className="card__accent">10</span>
                        </p>
                      </div>
                    </div>
                  </article>
                </a>
              </li>
              <li className="cards-list__item">
                <a href="/game-id.html" className="card-list__link">
                  <article className="card">
                    <img
                      src="https://code.s3.yandex.net/teens/pindie-games/defence-of-crystal/cover.png"
                      alt=""
                      className="card__image"
                    />
                    <div className="card__content-block">
                      <h3 className="card__title">Defence of Crystal</h3>
                      <p className="card__description">
                        Защищай магический кристалл от монстров и уничтожай кладбища, чтобы спасти Землю, которую поглотил мрак.
                      </p>
                      <div className="card__info-container">
                        <p className="card__author">
                          Автор: <span className="card__accent">MastWe</span>
                        </p>
                        <p className="card__votes">
                          Голосов на сайте: <span className="card__accent">20</span>
                        </p>
                      </div>
                    </div>
                  </article>
                </a>
              </li>
            </ul>
          </section>
          <section className="list-section">
            <h2 className="list-section__title" id="new">
              Новинки
            </h2>
            <ul className="cards-list">
              <li className="cards-list__item">
                <a href="/game-id.html" className="card-list__link">
                  <article className="card">
                    <img
                      src="https://code.s3.yandex.net/teens/pindie-games/go-away/cover.jpg"
                      alt=""
                      className="card__image"
                    />
                    <div className="card__content-block">
                      <h3 className="card__title">Go Away</h3>
                      <p className="card__description">
                        Управляй автомобилем, избегая аварий и перепрыгивая препятствия на пути к следующему уровню.
                      </p>
                      <div className="card__info-container">
                        <p className="card__author">
                          Автор: <span className="card__accent">Mahisto</span>
                        </p>
                        <p className="card__votes">
                          Голосов на сайте: <span className="card__accent">20</span>
                        </p>
                      </div>
                    </div>
                  </article>
                </a>
              </li>
              <li className="cards-list__item">
                <a href="/game-id.html" className="card-list__link">
                  <article className="card">
                    <img
                      src="https://code.s3.yandex.net/teens/pindie-games/gunner/cover.png"
                      alt=""
                      className="card__image"
                    />
                    <div className="card__content-block">
                      <h3 className="card__title">G.U.N.N.E.R.</h3>
                      <p className="card__description">
                        Продержись как можно дольше, отбиваясь от врагов, которых будет становиться всё больше.
                      </p>
                      <div className="card__info-container">
                        <p className="card__author">
                          Автор: <span className="card__accent">IDKWIAm</span>
                        </p>
                        <p className="card__votes">
                          Голосов на сайте: <span className="card__accent">10</span>
                        </p>
                      </div>
                    </div>
                  </article>
                </a>
              </li>
              <li className="cards-list__item">
                <a href="/game-id.html" className="card-list__link">
                  <article className="card">
                    <img
                      src="https://code.s3.yandex.net/teens/pindie-games/space-terror/cover.png"
                      alt=""
                      className="card__image"
                    />
                    <div className="card__content-block">
                      <h3 className="card__title">Space Terror</h3>
                      <p className="card__description">
                        Лети как можно дальше в космическом пространстве, уничтожая всё на своём пути.
                      </p>
                      <div className="card__info-container">
                        <p className="card__author">
                          Автор: <span className="card__accent">IDKWIAm</span>
                        </p>
                        <p className="card__votes">
                          Голосов на сайте: <span className="card__accent">20</span>
                        </p>
                      </div>
                    </div>
                  </article>
                </a>
              </li>
              <li className="cards-list__item">
                <a href="/game-id.html" className="card-list__link">
                  <article className="card">
                    <img
                      src="https://code.s3.yandex.net/teens/pindie-games/square-slayer/cover.png"
                      alt=""
                      className="card__image"
                    />
                    <div className="card__content-block">
                      <h3 className="card__title">Square Slayer</h3>
                      <p className="card__description">
                        Уворачивайся и отстреливайся от озлобленных квадратов и собирай жизни для перехода на следующий уровень.
                      </p>
                      <div className="card__info-container">
                        <p className="card__author">
                          Автор: <span className="card__accent">niclan</span>
                        </p>
                        <p className="card__votes">
                          Голосов на сайте: <span className="card__accent">10</span>
                        </p>
                      </div>
                    </div>
                  </article>
                </a>
              </li>
            </ul>
          </section>
          <section className="promo">
            <div className="promo__description-block">
              <h2 className="promo__title">Твой промо-код</h2>
              <p className="promo__description">Скидка на все курсы Яндекс Практикума для пользователей нашего сайта!</p>
              <button className="button promo__button">Получить код</button>
            </div>
            <img src="./images/promo-illustration.svg" alt="Собака" className="promo__image"/>
          </section>
        </main>
        <footer className="footer">
          <a href="./index.html" className="footer__logo">
            <span className="footer__logo-name">pindie</span
            ><span className="footer__logo-copy">, XXI век</span>
          </a>
          <ul className="social-list">
            <li className="social-list__item">
              <a href="" className="button social-list__link">YT</a>
            </li>
            <li className="social-list__item">
              <a href="" className="button social-list__link">ВК</a>
            </li>
            <li className="social-list__item">
              <a href="" className="button social-list__link">TG</a>
            </li>
          </ul>
        </footer>
      </body>
    </html>
  </main>)
}