/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/layout",{

/***/ "(app-pages-browser)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=D%3A%5Cpindie%5Capp%5Cglobals.css&modules=D%3A%5Cpindie%5Capp%5CComponents%5CHeader%5CHeader.module.css&modules=D%3A%5Cpindie%5Capp%5CComponents%5CFooter%5CFooter.module.css&server=false!":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=D%3A%5Cpindie%5Capp%5Cglobals.css&modules=D%3A%5Cpindie%5Capp%5CComponents%5CHeader%5CHeader.module.css&modules=D%3A%5Cpindie%5Capp%5CComponents%5CFooter%5CFooter.module.css&server=false! ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/globals.css */ \"(app-pages-browser)/./app/globals.css\"));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./app/Components/Header/Header.module.css */ \"(app-pages-browser)/./app/Components/Header/Header.module.css\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./app/Components/Footer/Footer.module.css */ \"(app-pages-browser)/./app/Components/Footer/Footer.module.css\", 23))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvYnVpbGQvd2VicGFjay9sb2FkZXJzL25leHQtZmxpZ2h0LWNsaWVudC1lbnRyeS1sb2FkZXIuanM/bW9kdWxlcz1EJTNBJTVDcGluZGllJTVDYXBwJTVDZ2xvYmFscy5jc3MmbW9kdWxlcz1EJTNBJTVDcGluZGllJTVDYXBwJTVDQ29tcG9uZW50cyU1Q0hlYWRlciU1Q0hlYWRlci5tb2R1bGUuY3NzJm1vZHVsZXM9RCUzQSU1Q3BpbmRpZSU1Q2FwcCU1Q0NvbXBvbmVudHMlNUNGb290ZXIlNUNGb290ZXIubW9kdWxlLmNzcyZzZXJ2ZXI9ZmFsc2UhIiwibWFwcGluZ3MiOiJBQUFBLDRKQUFpRTtBQUNqRSxrTkFBMkY7QUFDM0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLz8yNGMzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiRDpcXFxccGluZGllXFxcXGFwcFxcXFxnbG9iYWxzLmNzc1wiKTtcbmltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiRDpcXFxccGluZGllXFxcXGFwcFxcXFxDb21wb25lbnRzXFxcXEhlYWRlclxcXFxIZWFkZXIubW9kdWxlLmNzc1wiKTtcbmltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiRDpcXFxccGluZGllXFxcXGFwcFxcXFxDb21wb25lbnRzXFxcXEZvb3RlclxcXFxGb290ZXIubW9kdWxlLmNzc1wiKSJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(app-pages-browser)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=D%3A%5Cpindie%5Capp%5Cglobals.css&modules=D%3A%5Cpindie%5Capp%5CComponents%5CHeader%5CHeader.module.css&modules=D%3A%5Cpindie%5Capp%5CComponents%5CFooter%5CFooter.module.css&server=false!\n"));

/***/ })

});